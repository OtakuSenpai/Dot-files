#! /bin/bash

a='$var'

foo(
