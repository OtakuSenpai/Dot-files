#import <Foundation/Foundation.h>

int main()
{
   /* my first program in Objective-C */
   NSLog(@"Hello, World! \n");
   
   return 0;
}
